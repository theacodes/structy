from structy.structy import Struct, __doc__

__version__ = "2021.1.9"

__all__ = [
    "__doc__",
    "Struct"
]
